# PuraTunes Backend

This is a dummy backend API for PuraTunes. Deploy via Render or Railway.