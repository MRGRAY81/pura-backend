# PuraTunes Backend

Dummy backend for login and API testing. Deploy on Render using Node.js.